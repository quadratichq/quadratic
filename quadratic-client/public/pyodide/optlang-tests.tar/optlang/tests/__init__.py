# from optlang.tests.test_cplex_interface import *
#
# def test_all():
#     try:
#         from nose import run, runmodule, main
#     except ImportError:
#         print('Please install nosetests in order to run optlang tests.')
#     else:
#         # run(argv=[os.path.dirname(os.path.realpath(__file__)), 'test_glpk_interface'])
#         print(os.path.dirname(os.path.abspath(__file__)))
#         tests_dir = os.path.dirname(os.path.abspath(__file__))
#         # import glob
#         # glob.glob()
#         # run(argv=[tests_dir, '-vv'])
#         run(argv=['/Users/niso/Dev/optlang/optlang', '-vv'])
