from statsmodels.tools._testing import PytestTester

test = PytestTester()
