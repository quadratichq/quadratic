from pathlib import Path

data_dir = Path(__file__).parent / "data"
