/*!
 * Copyright 2022, by XGBoost Contributors
 */
#include "pseudo_huber.h"
namespace xgboost {
DMLC_REGISTER_PARAMETER(PesudoHuberParam);
}
